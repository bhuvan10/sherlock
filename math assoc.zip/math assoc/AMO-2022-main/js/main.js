question_content =
{
    "sequences":[
        {
        image:"../images/questions/Sequences/seq_1.png",
        value:"B"
        },
        {
            image:"../images/questions/Sequences/seq_2.png",
            value:"B"
        },
        {
            image:"../images/questions/Sequences/seq_3.png",
            value:"D"
            },
            {
                image:"../images/questions/Sequences/seq_4.png",
                value:"C"
                },
                {
                    image:"../images/questions/Sequences/seq_5.png",
                    value:"A"
                    },
                    {
                        image:"../images/questions/Sequences/seq_6.png",
                        value:"C"
                        }
        ]
        ,"AOD":[
           {
               image:"../images/questions/AOD/1.png",
               value:"B"
           },
           {
            image:"../images/questions/AOD/2.png",
            value:"C"
        },
        {
            image:"../images/questions/AOD/3.png",
            value:"B"
        },
        {
            image:"../images/questions/AOD/4.png",
            value:"A"
        },
        {
            image:"../images/questions/AOD/5.png",
            value:"D"
        },
        {
            image:"../images/questions/AOD/6.png",
            value:"A"
        }
        ],
        "Complex":[
            {
                image:"../images/questions/Complex/1.png",
                value:"C"
            },
            {
                image:"../images/questions/Complex/2.png",
                value:"B"
            },
            {
                image:"../images/questions/Complex/3.png",
                value:"C"
            },
            {
                image:"../images/questions/Complex/4.png",
                value:"A"
            },
            {
                image:"../images/questions/Complex/5.png",
                value:"C"
            },
            {
                image:"../images/questions/Complex/6.png",
                value:"C"
            }
        ],
        "ConicSections":[
            {
                image:"../images/questions/Conic Sections/1.png",
                value:"D"
            },
            {
                image:"../images/questions/Conic Sections/2.png",
                value:"B"
            },
            {
                image:"../images/questions/Conic Sections/3.png",
                value:"B"
            },
            {
                image:"../images/questions/Conic Sections/4.png",
                value:"C"
            },
            {
                image:"../images/questions/Conic Sections/5.png",
                value:"B"
            },
            {
                image:"../images/questions/Conic Sections/6.png",
                value:"A"
            }
        ],
        "FunctionsandRelations":[
            {
                image:"../images/questions/Functions and Relations/1.png",
                value:"A"
            },
            {
                image:"../images/questions/Functions and Relations/2.png",
                value:"B"
            },
            {
                image:"../images/questions/Functions and Relations/3.png",
                value:"B"
            },
            {
                image:"../images/questions/Functions and Relations/4.png",
                value:"C"
            },
            {
                image:"../images/questions/Functions and Relations/5.png",
                value:"D"
            },
            {
                image:"../images/questions/Functions and Relations/6.png",
                value:"D"
            }
        ],
        "Integration":[
            {
                image:"../images/questions/Integration/1.png",
                value:"A"
            },
            {
                image:"../images/questions/Integration/2.png",
                value:"A"
            },
            {
                image:"../images/questions/Integration/3.png",
                value:"A"
            },
            {
                image:"../images/questions/Integration/4.png",
                value:"B"
            },
            {
                image:"../images/questions/Integration/5.png",
                value:"A"
            },
            {
                image:"../images/questions/Integration/6.png",
                value:"A"
            },
        ]
}
let genre =Number(localStorage.getItem("Genre"));
console.log(genre);
getquestion(genre);
document.getElementById("total_coins").innerHTML= "you have "+localStorage.getItem("money")+" coins";
function getquestion(genre)
{
    if(genre==1)
    document.getElementById("question").src = question_content.sequences[3].image;
    else if(genre==2)
    document.getElementById("question").src = question_content.AOD[3].image;
    else if(genre==3)
    document.getElementById("question").src = question_content.Complex[3].image;
    else if(genre==4)
    document.getElementById("question").src = question_content.ConicSections[3].image;
    else if(genre==5)
    document.getElementById("question").src = question_content.FunctionsandRelations[3].image;
    else
    document.getElementById("question").src = question_content.Integration[3].image;

}
function scoreCalculate()
{
   let Val_A =   document.getElementById("A").value;
   let Val_B =   document.getElementById("B").value;
   let Val_C =   document.getElementById("C").value;
   let Val_D =   document.getElementById("D").value;

    let current__coins=Number(localStorage.getItem("money"));
    console.log(current__coins);
    let correct_answer=question_content.sequences[1].value;
    if(correct_answer=="A")
    current__coins=current__coins+Val_A*100-Val_B*100-Val_C*100-Val_D*100;
    else if(correct_answer=="B")
    current__coins=current__coins-Val_A*100+Val_B*100-Val_C*100-Val_D*100;
    else if(correct_answer=="C")
    current__coins=current__coins-Val_A*100-Val_B*100+Val_C*100-Val_D*100;
    else
    current__coins=current__coins-Val_A*100-Val_B*100-Val_C*100+Val_D*100;
}